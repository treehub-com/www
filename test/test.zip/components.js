/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.l = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// identity function for calling harmony imports with the correct context
/******/ 	__webpack_require__.i = function(value) { return value; };

/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};

/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};

/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 9);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = (superclass) => class extends superclass {
  constructor(args) {
    superclass.name === 'HTMLElement' ? super() : super(args);

    // We start out not connected
    this._connected = false;

    // Setup js getters/setters for each attribute
    // Attributes and getters/setters are always kept in sync
    // All attributes are strings, matching the dom spec/behavior
    const {attributes = []} = args;
    for (let attr of attributes) {
      Object.defineProperty(this, attr, {
        get: () => this.getAttribute(attr),
        // Setting to null removes the attribute,
        // and anything else is coerced to a string
        set: (val) => {
          if (val === null) {
            this.removeAttribute(attr);
          } else {
            this.setAttribute(attr, val);
          }
        },
      });
    }

    // Grab a template if passed in
    const {template = null, shadow = false} = args;
    if (template) {
      this._template = document.querySelector(`#${template}`);
      if (shadow) {
        this._root = this.attachShadow({mode: 'open'});
      } else {
        this._root = this;
      }
    }

    // Setup $ object, which we populate in connectedCallback
    const {$ = {}} = args;
    this.$ = $;
  }

  // Only call callbacks after we connect and if there is a registered handler
  attributeChangedCallback(attrName, oldVal, newVal) {
    if (this._connected && this[`_${attrName}Changed`]) {
      this[`_${attrName}Changed`].call(this, newVal, oldVal);
    }
  }

  connectedCallback() {
    // Spec says that connectedCallback may be called more than once,
    // so we guard against that
    if (this._connected) {
      return;
    }

    // If we have a template, add it to our root
    if (this._template) {
      this._root.appendChild(this._template.content.cloneNode(true));
      // Map all of our $ shortcuts
      for (let key of Object.keys(this.$)) {
        this.$[key] = this._root.querySelector(this.$[key]);
      }
    }

    // We are now connected
    this._connected = true;
  }
};


/***/ }),
/* 1 */
/***/ (function(module, exports, __webpack_require__) {

const core = __webpack_require__(0);

class Component extends core(HTMLElement) {
  constructor() {
    super({
      template: 'test-aside',
    });
  }
}

const template = __webpack_require__(5);
document.head.insertAdjacentHTML('beforeend', template);

window.customElements.define('test-aside', Component);


/***/ }),
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

const core = __webpack_require__(0);

class Component extends core(HTMLElement) {
  constructor() {
    super({
      template: 'test-nav',
    });
    this.addEventListener('click', () => {
      window.page = '/test/#/test/';
    });
  }
}

const template = __webpack_require__(6);
document.head.insertAdjacentHTML('beforeend', template);

window.customElements.define('test-nav', Component);


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

const core = __webpack_require__(0);

class Component extends core(HTMLElement) {
  constructor() {
    super({
      template: 'test-page',
    });
  }

  connectedCallback() {
    super.connectedCallback();

    fetch('/test/', {
      method: 'POST',
    })
    .then((res) => res.text())
    .then((data) => {
      this.insertAdjacentHTML('beforeend', data);
    });
  }
}

const template = __webpack_require__(7);
document.head.insertAdjacentHTML('beforeend', template);

window.customElements.define('test-page', Component);


/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

const core = __webpack_require__(0);

class Component extends core(HTMLElement) {
  constructor() {
    super({
      template: 'test-taskbar',
    });
  }
}

const template = __webpack_require__(8);
document.head.insertAdjacentHTML('beforeend', template);

window.customElements.define('test-taskbar', Component);


/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = "<style>\n  test-aside {\n    display: flex;\n    align-items: center;\n  }\n</style>\n\n<template id=\"test-aside\">\n  test-aside\n</template>\n"

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = "<style>\n  test-nav {\n    display: flex;\n  }\n</style>\n\n<template id=\"test-nav\">\n  test\n</template>\n"

/***/ }),
/* 7 */
/***/ (function(module, exports) {

module.exports = "<style>\n  test-page {\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    width: 100%;\n  }\n</style>\n\n<template id=\"test-page\">\n  test-page\n</template>\n"

/***/ }),
/* 8 */
/***/ (function(module, exports) {

module.exports = "<style>\n  test-taskbar {\n    display: flex;\n  }\n</style>\n\n<template id=\"test-taskbar\">\n  test-taskbar\n</template>\n"

/***/ }),
/* 9 */
/***/ (function(module, exports, __webpack_require__) {

__webpack_require__(3);
__webpack_require__(4);
__webpack_require__(2);
module.exports = __webpack_require__(1);


/***/ })
/******/ ]);