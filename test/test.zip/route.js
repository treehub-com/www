async function route() {
  return 'Test Route Success!';
}

module.exports = async () => {
  return route;
};
